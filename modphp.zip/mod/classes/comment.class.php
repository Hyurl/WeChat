<?php
/** 评论模块 */
final class comment extends mod{
	const TABLE = 'comment';
	const PRIMKEY = 'comment_id';
}