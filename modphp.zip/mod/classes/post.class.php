<?php
/** 文章模块 */
final class post extends mod{
	const TABLE = 'post';
	const PRIMKEY = 'post_id';
}